#!/usr/bin/env bash

# Make this file executable first: "chmod +x ESPlorer.sh", then double-click on it

java -jar ESPlorer.jar
